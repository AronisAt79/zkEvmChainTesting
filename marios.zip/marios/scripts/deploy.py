from brownie import accounts, ERC20_TOKEN
from web3 import Web3
# from decimal import Decimal

w3 = Web3(Web3.HTTPProvider('http://127.0.0.1:8545'))

def main():
    admin = accounts[3]
    user1 = accounts[0]
    user2 = accounts[1]

    token = ERC20_TOKEN.deploy("My_Token", "MyT", 18, {"from": admin})
    print(token)

    name = token.name()
    symbol = token.symbol()
    decimals = token.decimals()
    balanceOfAdmin = token.balanceOf(admin)
    domainSep = token.DOMAIN_SEPARATOR()

    print(domainSep)
    print(name, symbol, decimals)
    print(f"Balance of {admin} is {balanceOfAdmin*1e-18}")

    tx1 = token.transfer(user1, w3.toWei(1, 'ether'))
    tx1.wait(1)

    newBalanceOfAdmin = token.balanceOf(admin)
    newBalanceOfUser1 = token.balanceOf(user1)

    print(f"User {admin}: {newBalanceOfAdmin}")
    print(f"User {user1}: {newBalanceOfUser1}")

    print(w3.eth.get_balance(admin.address)*1e-18)
    print(w3.eth.get_balance('0x8D5004fc1531945146Fb2b87231C9FE0e82624a9')*1e-18)
    print(user1.balance()*1e-18)
    print(user2.balance()*1e-18)
